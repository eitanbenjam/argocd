module.exports = {
  NON_VERSION_SENSITIVE_FILES: [
    {{- range .Values.xmlFiles.NON_VERSION_SENSITIVE_FILES }}
    {{ . | quote }},
    {{- end }}
  ],
  NON_VERSION_IGNORE_LIST: [
    {{- range .Values.xmlFiles.NON_VERSION_IGNORE_LIST }}
    {{ . | quote }},
    {{- end }}
  ],
  VERSION_SENSITIVE_FILES: [
    {{- range .Values.xmlFiles.VERSION_SENSITIVE_FILES }}
    {{ . | quote }},
    {{- end }}
  ],
}
